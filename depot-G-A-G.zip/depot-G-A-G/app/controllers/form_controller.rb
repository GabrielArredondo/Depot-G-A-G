class FormController < ApplicationController
  def input
  end
end
