module AdminHelper
end
